define({"button.formatlessPaste.tooltip":"Einf\u00fcgen ohne Formatierung ein/ausschalten."});
