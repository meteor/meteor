define(
	{"button.addtoc.tooltip":"Table of contents"}
);